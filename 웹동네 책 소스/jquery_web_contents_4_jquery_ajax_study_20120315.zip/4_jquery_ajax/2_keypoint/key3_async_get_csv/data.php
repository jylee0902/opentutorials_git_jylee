<?php
	$data1 = $_GET["data1"];
	$data2	=$_GET["data2"];
	
	echo("data1=".$data1."|data2=".$data2);
?>